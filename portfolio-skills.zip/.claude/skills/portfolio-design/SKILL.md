---
name: portfolio-design
description: |
  Design and build portfolio website pages, sections, and components with a warm,
  human aesthetic rooted in real-world architectural and urban design sensibility.
  Use this skill whenever building or styling any portfolio page, section, layout,
  hero, project card, navigation, footer, about page, contact section, or any
  visual/UI component for the portfolio site. Also trigger when the user asks to
  make something "look better," "feel warmer," or wants design direction on any
  part of the portfolio.
---

# Portfolio Design Skill

Build a portfolio that feels like a place someone designed by hand — warm, textured,
and intentional. Not a template. Not AI slop. Something with personality.

## Design Philosophy

This portfolio belongs to an urban planner and designer. The aesthetic should reflect that:

- **Warm over clinical.** Think sandstone, terracotta, aged paper — not sterile white
  cards on grey backgrounds. The site should feel like walking through a well-designed
  neighborhood, not scrolling through a SaaS landing page.
- **Structure with softness.** Urban planning is about grids and systems, but the best
  cities have irregularity and surprise. Use strong layout grids but break them
  intentionally — an image that bleeds past its column, text that shifts alignment.
- **Materiality.** Subtle textures, grain, shadow depth. Real things cast shadows and
  have weight. Flat design is fine if it has craft — but never default-flat.
- **Typography with character.** Pick display fonts with personality (serif or
  humanist sans — never Inter, Roboto, or system defaults). Pair with a clean body
  font. Google Fonts options: DM Serif Display + DM Sans, Playfair Display + Source Sans 3,
  Fraunces + Work Sans, Literata + Nunito Sans, or similar pairings with warmth.

## Color Direction

Avoid: purple gradients, neon accents, pure black on pure white, generic blue.

Lean toward palettes inspired by built environments and natural materials:
- Warm neutrals: cream, sand, warm grey, charcoal (not pure black)
- Earth accents: terracotta, olive, ochre, clay, deep teal
- Contrast through value, not saturation

Define all colors as CSS custom properties. Example:
```css
:root {
  --color-bg: #FAF6F1;
  --color-surface: #F0EAE0;
  --color-text: #2C2826;
  --color-text-muted: #6B6560;
  --color-accent: #C4704B;
  --color-accent-hover: #A85A38;
  --color-border: #DDD5CA;
}
```

## Layout Principles

- **Generous whitespace.** Let content breathe. Padding should feel luxurious.
- **Max content width ~1100-1200px.** Don't stretch text across full viewport.
- **Asymmetric where it counts.** Hero sections, project features, about page —
  avoid perfectly centered symmetry for everything. Offset images, stagger grids.
- **Mobile-first responsive.** Single column on mobile, expand on larger screens.
  Breakpoints: 640px, 768px, 1024px, 1280px.

## Component Patterns

### Navigation
- Clean, minimal. Logo/name on left, links on right.
- No hamburger menu on desktop. Simple horizontal links.
- Mobile: slide-out or full-screen overlay menu — not a tiny dropdown.
- Current page indicator: underline or subtle highlight, not bold color block.

### Hero / Landing
- Strong opening statement — not "Welcome to my portfolio."
- Consider: a single compelling sentence about what you do and care about.
- Background: subtle texture or muted image, not a full-bleed stock photo.
- Scroll indicator if content continues below fold.

### Project Cards / Grid
- Show the work, not just titles. Lead with images or maps.
- Hover states that feel physical: slight lift, shadow shift, subtle scale.
- Grid: 2 columns on desktop, 1 on mobile. Avoid 3+ columns — portfolio
  projects need room.
- Each card: image/visual, project title, 1-line description, tags/skills used.

### Project Detail Pages
- Large hero image or map at top.
- Clear structure: Context → Problem → Approach → Outcome.
- Use real images, diagrams, maps — never placeholder stock.
- Pull quotes or key findings as callouts (not in generic blockquote style).
- Related projects at bottom.

### About Section
- Photo + text side by side (not centered headshot-above-paragraph).
- Voice should be first-person and direct. Not third-person corporate bio.
- Mention actual interests and perspective, not just credentials.

### Contact / Footer
- Simple. Email link, LinkedIn, maybe GitHub.
- No contact form unless there's a backend to receive it.
- Footer: minimal, warm sign-off or quote. Not a wall of links.

## Animation & Motion

- **Entrance animations:** Subtle fade-up on scroll (IntersectionObserver).
  Stagger children by 50-100ms. Duration: 400-600ms. Ease: cubic-bezier(0.25, 0.1, 0.25, 1).
- **Hover effects:** Scale 1.01-1.03 on cards. Color transitions on links (200ms).
- **Page transitions:** Smooth if using a framework (Next.js, Astro). Otherwise,
  keep it to scroll-based reveals.
- **Never:** Bouncing elements, spinning loaders for no reason, parallax that
  makes people dizzy, typewriter effects on every heading.

## Code Quality

- Semantic HTML always. `<header>`, `<main>`, `<section>`, `<article>`, `<footer>`.
- CSS custom properties for all colors, spacing, and font sizes.
- Component-based if using React/Next.js — one file per component.
- Images: use `<picture>` or framework image components with lazy loading.
  Always include `alt` text.
- Responsive images with `srcset` where possible.

## What to Avoid

- LinkedIn-style headshot circles
- "Passionate about..." opening lines
- Generic skill bars or percentage charts
- Testimonial carousels (unless there are real testimonials)
- Dark mode toggle for the sake of it (pick one theme and do it well)
- Cookie-cutter template layouts from Vercel/Next.js starters
- Emoji as decorative elements
- "Built with React" badges in the footer
