---
name: portfolio-accessibility
description: |
  Ensure the portfolio website meets accessibility standards and works well across
  all devices. Use this skill when building any new component or page, when
  reviewing existing code for accessibility issues, when handling responsive
  breakpoints, when adding images or media, or when the user mentions accessibility,
  a11y, screen readers, keyboard navigation, contrast, or responsive/mobile design.
---

# Portfolio Accessibility & Responsive Skill

Every page and component must be accessible and responsive from the start —
not patched in later.

## Accessibility Baseline

### Semantic HTML
- Use landmarks: `<header>`, `<nav>`, `<main>`, `<section>`, `<article>`, `<footer>`
- One `<h1>` per page. Heading hierarchy never skips levels (h1 → h2 → h3).
- Use `<button>` for actions, `<a>` for navigation. Never `<div onclick>`.
- Lists for navigation links: `<ul>` + `<li>` inside `<nav>`.
- Use `<figure>` + `<figcaption>` for images with captions.

### Color & Contrast
- Minimum 4.5:1 contrast for body text (WCAG AA).
- Minimum 3:1 for large text (18px+ bold or 24px+ regular).
- Never convey information by color alone — add icons, labels, or patterns.
- Test with: https://webaim.org/resources/contrastchecker/

### Keyboard Navigation
- All interactive elements must be focusable and operable via keyboard.
- Visible focus indicators on all focusable elements — never `outline: none`
  without a replacement.
- Focus order follows visual reading order (DOM order matches layout).
- Skip-to-content link as first focusable element:
```html
<a href="#main-content" class="skip-link">Skip to main content</a>
```
```css
.skip-link {
  position: absolute;
  top: -40px;
  left: 0;
  padding: 8px 16px;
  z-index: 100;
  background: var(--color-accent);
  color: white;
}
.skip-link:focus {
  top: 0;
}
```

### Images & Media
- Every `<img>` needs an `alt` attribute. Decorative images: `alt=""`.
- Descriptive alt text for content images (see portfolio-content skill).
- SVG icons: `aria-hidden="true"` if decorative, `role="img"` + `aria-label` if meaningful.
- Videos: provide captions or transcripts.

### Forms (if contact form exists)
- Every input needs a visible `<label>` element linked via `for`/`id`.
- Error messages linked to inputs with `aria-describedby`.
- Don't rely on placeholder text as the only label.

### ARIA (use sparingly)
- Prefer semantic HTML over ARIA. ARIA is a supplement, not a replacement.
- Mobile menu: `aria-expanded`, `aria-controls` on the toggle button.
- Current page in nav: `aria-current="page"`.
- Loading states: `aria-busy="true"` on the container.

### Motion & Animation
- Respect `prefers-reduced-motion`:
```css
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
    scroll-behavior: auto !important;
  }
}
```

## Responsive Design

### Breakpoints
```css
/* Mobile first — base styles are mobile */
/* Tablet */
@media (min-width: 640px) { }
/* Small desktop */
@media (min-width: 768px) { }
/* Desktop */
@media (min-width: 1024px) { }
/* Wide desktop */
@media (min-width: 1280px) { }
```

### Layout Rules
- Single column on mobile. No horizontal scrolling ever.
- Touch targets: minimum 44x44px on mobile.
- Font sizes: minimum 16px body text on mobile (prevents iOS zoom).
- Images: `max-width: 100%; height: auto;` as baseline.
- Navigation: collapse to hamburger/overlay below 768px.
- Project grid: 1 column mobile → 2 columns desktop.
- Side-by-side layouts (about page): stack vertically on mobile.

### Typography Scaling
Use `clamp()` for fluid typography:
```css
h1 { font-size: clamp(2rem, 5vw, 3.5rem); }
h2 { font-size: clamp(1.5rem, 3vw, 2.25rem); }
body { font-size: clamp(1rem, 1.2vw, 1.125rem); }
```

### Testing Checklist
Before shipping any page:
- [ ] Tab through the entire page — can you reach and operate everything?
- [ ] Resize browser from 320px to 1440px — does layout hold?
- [ ] Test with browser zoom at 200%
- [ ] Run Lighthouse accessibility audit (aim for 95+)
- [ ] Check heading hierarchy (no skipped levels)
- [ ] Verify all images have appropriate alt text
- [ ] Test color contrast on all text elements
- [ ] Verify reduced-motion media query works
