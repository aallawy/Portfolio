---
name: portfolio-content
description: |
  Write portfolio copy, project descriptions, about sections, case study narratives,
  and any text content for the portfolio website. Use this skill when writing or
  editing any text that appears on the portfolio — hero taglines, project writeups,
  about page copy, meta descriptions, section headings, or alt text. Also use when
  the user asks to "write," "rewrite," "make it sound better," or draft any
  portfolio-related text content.
---

# Portfolio Content Skill

Write portfolio copy that sounds like a real person talking about work they care
about. Not a resume. Not a LinkedIn summary. Not corporate jargon.

## Voice and Tone

- **First person, direct.** "I" not "Alissa is a..." — save third person for
  formal bios on other platforms.
- **Confident without performing.** State what you did and why it matters.
  Don't hedge with "I was fortunate to..." or inflate with "I spearheaded
  the transformation of..."
- **Specific over abstract.** "I mapped 200+ early childhood programs across
  Metro Vancouver" beats "I conducted comprehensive research."
- **Honest about perspective.** Being a daily transit rider who studies transit
  planning is a real qualification. Lived experience is not a soft credential —
  name it plainly.
- **Short sentences are fine.** So are fragments. Vary rhythm. Don't write
  everything in the same cadence.

## AI Writing Patterns to Avoid

These make portfolio copy sound generated. Never use them:

- "Passionate about..." / "Dedicated to..."
- "At the intersection of..."
- "Leveraging" / "Utilizing" / "Spearheading"
- "Innovative solutions" / "Cutting-edge" / "Best-in-class"
- "A testament to..." / "Underscoring the importance of..."
- Em dash overuse — especially — when used — to insert — multiple asides
- Rule of three: "designing, developing, and delivering"
- "In today's rapidly evolving landscape..."
- Ending with vague optimism: "The future looks bright"
- Starting with "Great question!" or "Absolutely!"
- "Not just X, but Y" parallelism
- "It's worth noting that..."

## Section-Specific Guidance

### Hero / Opening Line
Keep it to one strong sentence. What do you actually do, and what lens do you
bring to it?

Good examples of the *vibe* (don't copy these, write your own):
- "I plan cities around the people who already live in them."
- "Urban planner. Transit rider. I design the networks I depend on."
- "Making transit work for the people who need it most."

Bad examples:
- "Welcome to my portfolio!"
- "I'm a passionate urban planning student..."
- "Exploring the intersection of design, data, and community."

### Project Descriptions (Card Level)
One sentence. What was the project and what was the core output?
- "Gap analysis of early childhood programs across Metro Vancouver for
  New Westminster Family Place."
- "Green urbanism proposal applying courtyard principles to North York Centre."

### Project Case Studies (Full Page)
Structure: Context → Problem → What I Did → What I Found/Made → What It Means

Write each section in 2-4 sentences max. Use subheadings. Include:
- The actual deliverable (report, map, design proposal, service plan)
- Tools used, stated plainly: "Built in ArcGIS" not "Utilized geospatial
  information systems"
- One specific finding or design decision that shows judgment, not just execution
- Images, maps, or diagrams with real captions (not "Figure 1")

### About Page
Write it like you'd introduce yourself to someone at a conference who asked
what you do. Include:
- What you study and where (briefly)
- What you actually care about in planning (transit, active transport, equity)
- Your lived experience angle — daily rider, understands the system from inside
- What tools you work with (GIS, NVivo, Adobe — stated casually)
- Where you're from / what shapes your design eye (if relevant to the work)

Don't include:
- A chronological resume walkthrough
- Every course you've taken
- "In my free time I enjoy..."
- Generic closer about "making a difference"

### Meta Descriptions / SEO
Write 150-160 character descriptions for each page. Plain language, include
the core topic. Don't stuff keywords.

### Alt Text for Images
Describe what's in the image for someone who can't see it. Be specific:
- Good: "Map showing density of early childhood programs in Surrey, BC,
  with program locations marked in orange"
- Bad: "Research map" / "Project image" / "Figure 3"

## Formatting in Code

- Use markdown or structured HTML — never dump a wall of text into a single `<p>`.
- Break content into short paragraphs (2-3 sentences each).
- Use `<strong>` sparingly and only for genuinely important terms.
- Headings should be descriptive, not clever: "What I found" over "Unveiling
  the insights."
