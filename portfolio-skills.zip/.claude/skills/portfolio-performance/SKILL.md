---
name: portfolio-performance
description: |
  Optimize portfolio website performance, SEO, metadata, and deployment readiness.
  Use this skill when optimizing images, improving page load speed, adding meta
  tags, setting up Open Graph/social sharing, configuring deployment (Vercel,
  Netlify, GitHub Pages), setting up analytics, improving Lighthouse scores, or
  when the user mentions SEO, performance, page speed, deployment, hosting,
  social sharing previews, or sitemap.
---

# Portfolio Performance & Deployment Skill

Make the portfolio fast, findable, and ready to share.

## Performance

### Images (biggest impact)
- Use modern formats: WebP or AVIF with JPEG/PNG fallback.
- Resize images to the largest size they'll display (not 4000px originals).
- Lazy load below-fold images: `loading="lazy"` on `<img>`.
- Hero/above-fold images: `loading="eager"` + `fetchpriority="high"`.
- Use `<picture>` for art direction or format fallbacks:
```html
<picture>
  <source srcset="project.avif" type="image/avif">
  <source srcset="project.webp" type="image/webp">
  <img src="project.jpg" alt="..." loading="lazy">
</picture>
```
- If using Next.js: use `next/image` — it handles optimization automatically.
- If using Astro: use the built-in `<Image />` component.

### Fonts
- Limit to 2 font families (display + body).
- Use `font-display: swap` to prevent invisible text during load.
- Preload critical fonts:
```html
<link rel="preload" href="/fonts/display.woff2" as="font" type="font/woff2" crossorigin>
```
- Self-host fonts when possible (faster than Google Fonts CDN for most cases).
- Subset fonts to Latin characters if you only need English.

### CSS & JS
- Minimize render-blocking CSS. Inline critical CSS if possible.
- Defer non-essential JS: `<script defer>` or `<script type="module">`.
- Remove unused CSS (PurgeCSS or framework tree-shaking).
- Avoid large JS libraries for simple interactions — vanilla JS or CSS-only
  for scroll animations, hover effects, mobile menus.

### Core Web Vitals Targets
- LCP (Largest Contentful Paint): < 2.5s
- FID (First Input Delay): < 100ms
- CLS (Cumulative Layout Shift): < 0.1
- Set explicit `width` and `height` on images to prevent layout shift.

## SEO

### Page-Level Meta
Every page needs:
```html
<title>Page Title — Your Name</title>
<meta name="description" content="150-160 char description">
<link rel="canonical" href="https://yourdomain.com/page">
```

### Open Graph (social sharing previews)
```html
<meta property="og:title" content="Page Title">
<meta property="og:description" content="Short description">
<meta property="og:image" content="https://yourdomain.com/og-image.jpg">
<meta property="og:url" content="https://yourdomain.com/page">
<meta property="og:type" content="website">
<meta name="twitter:card" content="summary_large_image">
```
- OG image: 1200x630px. Include your name and a visual that represents
  the page content. This is what people see when they share your link.

### Structured Data (optional but nice)
Add JSON-LD for Person schema on the about/home page:
```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Person",
  "name": "Your Name",
  "url": "https://yourdomain.com",
  "jobTitle": "Urban Planner",
  "sameAs": [
    "https://linkedin.com/in/yourprofile"
  ]
}
</script>
```

### Sitemap & Robots
- Generate a sitemap.xml (most frameworks do this automatically).
- robots.txt:
```
User-agent: *
Allow: /
Sitemap: https://yourdomain.com/sitemap.xml
```

### Content SEO
- One `<h1>` per page, descriptive of the page content.
- Use descriptive URLs: `/projects/north-york-green-urbanism` not `/project/3`.
- Internal links between project pages and the main projects listing.
- Alt text on all images (double duty: accessibility + SEO).

## Deployment

### Vercel (recommended for Next.js/React)
- Connect GitHub repo → auto-deploys on push to main.
- Set environment variables in Vercel dashboard if needed.
- Custom domain: add in Vercel settings, update DNS records.
- Preview deployments on every PR — use them to review before merging.

### Netlify (good for static sites, Astro, Hugo)
- Same Git-based deploy flow as Vercel.
- `netlify.toml` for build settings:
```toml
[build]
  command = "npm run build"
  publish = "dist"
```

### GitHub Pages (free, simple)
- Works well for fully static sites.
- Deploy from `gh-pages` branch or GitHub Actions workflow.
- Custom domain via CNAME file in repo root.

### Pre-Deploy Checklist
- [ ] All pages render correctly on mobile and desktop
- [ ] Lighthouse scores: Performance 90+, Accessibility 95+, SEO 90+
- [ ] OG images render correctly (test at https://www.opengraph.xyz/)
- [ ] 404 page exists and is styled
- [ ] All links work (no broken internal/external links)
- [ ] Favicon and apple-touch-icon set
- [ ] Analytics connected (if desired)
- [ ] Console has no errors
- [ ] Forms work (if any exist)
- [ ] Custom domain configured with HTTPS
