# Portfolio Website

## About This Project
Personal portfolio website for an urban planner specializing in transportation
planning, active transportation, and transit service design in the GTHA.

## Design Direction
- Warm, human aesthetic — not clinical or template-y
- Inspired by built environments: sandstone, terracotta, textured surfaces
- Strong typographic choices (no Inter, Roboto, or system font defaults)
- Generous whitespace, asymmetric layouts where appropriate
- Mobile-first responsive design

## Writing Voice
- First person, direct, honest
- No corporate jargon or AI-sounding phrases
- Specific over abstract — name actual tools, real numbers, concrete outcomes
- Lived experience (daily transit rider) is a real qualification, state it plainly

## Technical Standards
- Semantic HTML with proper heading hierarchy
- WCAG AA accessibility minimum (4.5:1 contrast, keyboard nav, alt text)
- Respect `prefers-reduced-motion`
- Lazy load below-fold images, optimize all assets
- Target Lighthouse scores: Performance 90+, Accessibility 95+, SEO 90+

## Skills
This project includes custom skills in `.claude/skills/` — use them:
- `portfolio-design` — visual design, layout, typography, animation
- `portfolio-content` — writing copy, project descriptions, about section
- `portfolio-accessibility` — a11y standards, responsive design
- `portfolio-performance` — SEO, image optimization, deployment
